import { useState } from "react";

function CropDiagnosis() {
    const [image, setImage] = useState(null);

    function handleImageUpload(event) {
        const file = event.target.files[0];

        if (!file) return;

        setImage(URL.createObjectURL(file));
    }

    return (
        <div className="crop-page">

            <div className="crop-card">

                <h1>Crop Diagnosis</h1>

                <p>
                    Upload a crop image and let GroWell AI analyze it.
                </p>

                <input
                    type="file"
                    accept="image/*"
                    onChange={handleImageUpload}
                />

                {image && (
                    <div className="preview">

                        <img
                            src={image}
                            alt="Crop Preview"
                        />

                    </div>
                )}

                <button className="analyze-btn">
                    Analyze Crop
                </button>

            </div>
        </div>
    );
}

export default CropDiagnosis;