import Header from "../components/Header/Header";
import Sidebar from "../components/Sidebar/Sidebar";
import Chat from "../components/Chat/Chat";

import "./Dashboard.css";

function Dashboard() {

    return (

        <div className="dashboard-layout">

            <Sidebar />

            <div className="dashboard-main">

                <Header />

                <Chat />

            </div>

        </div>

    );

}

export default Dashboard;