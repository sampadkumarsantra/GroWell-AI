import { useEffect, useRef, useState } from "react";

import MessageList from "./MessageList";
import ChatInput from "./ChatInput";
import CropPreview from "./CropPreview";

function Chat() {
    const [message, setMessage] = useState("");
    const [messages, setMessages] = useState([]);
    const [isTyping, setIsTyping] = useState(false);
    const [selectedImage, setSelectedImage] = useState(null);
    const [selectedFile, setSelectedFile] = useState(null);
   const [isAnalyzing, setIsAnalyzing] = useState(false);
    const messagesEndRef = useRef(null);
    const fileInputRef = useRef(null);

    useEffect(() => {
        messagesEndRef.current?.scrollIntoView({
            behavior: "smooth",
        });
    }, [messages, isTyping]);

    function handleSuggestionClick(prompt) {
        setMessage(prompt);
    }

    function handleKeyDown(e) {
        if (e.key === "Enter") {
            sendMessage();
        }
    }

    function openImagePicker() {
        fileInputRef.current?.click();
    }

    function handleImageUpload(e) {
function removeImage() {
   async function analyzeCrop() {

    setIsAnalyzing(true);

    setTimeout(() => {

        setMessages(prev => [
            ...prev,
            {
                sender: "bot",
                text: "🌿 Crop image received successfully. AI Vision integration is coming next."
            }
        ]);

        setIsAnalyzing(false);

    }, 1500);

}
    setSelectedImage(null);

    if (fileInputRef.current) {
        fileInputRef.current.value = "";
    }
}
    const file = e.target.files?.[0];

    if (!file) return;

    setSelectedFile(file);

    const imageUrl = URL.createObjectURL(file);

    setSelectedImage(imageUrl);

}
    function startVoiceInput() {
        const SpeechRecognition =
            window.SpeechRecognition ||
            window.webkitSpeechRecognition;

        if (!SpeechRecognition) {
            alert("Speech Recognition is not supported in this browser.");
            return;
        }

        const recognition = new SpeechRecognition();

        recognition.lang = "en-US";
        recognition.interimResults = false;
        recognition.maxAlternatives = 1;

        recognition.onresult = (event) => {
            const transcript =
                event.results[0][0].transcript;

            setMessage(transcript);

            setTimeout(() => {
                sendMessage(transcript);
            }, 100);
        };

        recognition.onerror = (event) => {
            console.error(event.error);
        };

        recognition.start();
    }

    async function sendMessage(customMessage = null) {
        const userMessage = customMessage ?? message;

        if (!userMessage.trim()) return;

        setMessages((prev) => [
            ...prev,
            {
                sender: "user",
                text: userMessage,
            },
        ]);

        setMessage("");
        setIsTyping(true);

        try {
            const response = await fetch(
                "http://localhost:3000/api/chat",
                {
                    method: "POST",
                    headers: {
                        "Content-Type": "application/json",
                    },
                    body: JSON.stringify({
                        message: userMessage,
                    }),
                }
            );

            const data = await response.json();

            setIsTyping(false);

            if (!response.ok) {
                throw new Error(
                    data.reply || "Server Error"
                );
            }

            setMessages((prev) => [
                ...prev,
                {
                    sender: "bot",
                    text: data.reply,
                },
            ]);
        } catch (error) {
            console.error(error);

            setIsTyping(false);

            setMessages((prev) => [
                ...prev,
                {
                    sender: "bot",
                    text: "Unable to contact GroWell AI.",
                },
            ]);
        }
    }

    return (
        <div className="chat-container">
<CropPreview
    image={selectedImage}
    onAnalyze={analyzeCrop}
    onRemove={removeImage}
    isAnalyzing={isAnalyzing}
/>
            <MessageList
    messages={messages}
    isTyping={isTyping}
    selectedImage={selectedImage}
    onSuggestionClick={handleSuggestionClick}
    messagesEndRef={messagesEndRef}
    
/>

            <ChatInput
                message={message}
                setMessage={setMessage}
                handleKeyDown={handleKeyDown}
                sendMessage={sendMessage}
                startVoiceInput={startVoiceInput}
                openImagePicker={openImagePicker}
                handleImageUpload={handleImageUpload}
                fileInputRef={fileInputRef}
            />

        </div>
    );
}

export default Chat;

