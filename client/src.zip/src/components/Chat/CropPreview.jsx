function CropPreview({
    image,
    onAnalyze,
    onRemove,
    isAnalyzing = false
}) {

    if (!image) return null;

    return (
        <div className="chat-image-preview">

            <img
                src={image}
                alt="Crop Preview"
            />

            <div className="crop-preview-actions">

                <button
                    className="analyze-image-btn"
                    onClick={onAnalyze}
                    disabled={isAnalyzing}
                >
                    {isAnalyzing ? "⏳ Analyzing..." : "🔬 Analyze Crop"}
                </button>

                <button
                    className="remove-image-btn"
                    onClick={onRemove}
                >
                    ✖ Remove
                </button>

            </div>

        </div>
    );
}

export default CropPreview;