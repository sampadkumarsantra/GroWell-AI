import "./Header.css";
import {
    Bell,
    Search,
    CircleUserRound
} from "lucide-react";

function Header() {

    const hour = new Date().getHours();

    let greeting = "Good Evening";

    if (hour < 12) greeting = "Good Morning";
    else if (hour < 17) greeting = "Good Afternoon";

    return (

        <header className="gw-header">

            <div className="header-left">

                <h1>{greeting} 👋</h1>

                <p>
                    Welcome back to <strong>GroWell AI</strong>
                </p>

            </div>

            <div className="header-right">

                <div className="search-box">

                    <Search size={18} />

                    <input
                        type="text"
                        placeholder="Search features..."
                    />

                </div>

                <button className="icon-btn">
                    <Bell size={20} />
                </button>

                <button className="profile-btn">

                    <CircleUserRound size={34} />

                </button>

            </div>

        </header>

    );

}

export default Header;