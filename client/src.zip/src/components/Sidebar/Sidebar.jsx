import {
  MessageSquare,
  ScanLine,
  CloudSun,
  Sprout,
  FlaskConical,
  BarChart3,
  Settings,
} from "lucide-react";

import "./Sidebar.css";

const menu = [
  { icon: MessageSquare, label: "Chat", active: true },
  { icon: ScanLine, label: "Crop Diagnosis" },
  { icon: CloudSun, label: "Weather" },
  { icon: Sprout, label: "Soil Health" },
  { icon: FlaskConical, label: "Fertilizer" },
  { icon: BarChart3, label: "Analytics" },
  { icon: Settings, label: "Settings" },
];

function Sidebar() {
  return (
    <aside className="gw-sidebar">

      <div className="gw-logo">

        <div className="logo-circle">
          🌿
        </div>

        <div>
          <h2>GroWell AI</h2>
          <p>Cultivating Intelligence</p>
        </div>

      </div>

      <nav className="gw-nav">

        {menu.map((item) => {

          const Icon = item.icon;

          return (
            <button
              key={item.label}
              className={item.active ? "active" : ""}
            >
              <Icon size={20} />
              <span>{item.label}</span>
            </button>
          );

        })}

      </nav>

      <div className="sidebar-footer">

        <div className="status-dot"></div>

        <span>AI Online</span>

      </div>

    </aside>
  );
}

export default Sidebar;